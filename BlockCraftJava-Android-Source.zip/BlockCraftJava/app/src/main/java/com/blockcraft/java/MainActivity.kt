package com.blockcraft.java

import android.app.Activity
import android.app.AlertDialog
import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/**
 * BlockCraft Java Ultra is a small, independent launcher hub.
 * It does not contain Minecraft or a Java game engine; it opens an installed,
 * compatible Android Java launcher and provides setup guides.
 */
class MainActivity : Activity() {
    private val bg = 0xFF07110D.toInt()
    private val panel = 0xFF101F18.toInt()
    private val panelLight = 0xFF172B20.toInt()
    private val green = 0xFF8BEE5E.toInt()
    private val white = 0xFFF2F7F1.toInt()
    private val muted = 0xFFA0B5A5.toInt()
    private var engineStatus: TextView? = null

    private data class Engine(val label: String, val packageName: String)

    // Amethyst releases may use a Pojav-compatible package ID; both are checked.
    private val engines = listOf(
        Engine("Amethyst", "org.angelauramc.amethyst"),
        Engine("Amethyst / Pojav-compatible", "net.kdt.pojavlaunch"),
        Engine("Fold Craft Launcher", "com.tungsten.fcl")
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        buildScreen()
    }

    override fun onResume() {
        super.onResume()
        refreshEngineStatus()
    }

    private fun buildScreen() {
        val scroll = ScrollView(this).apply {
            setBackgroundColor(bg)
            isFillViewport = true
            clipToPadding = false
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(22), dp(20), dp(28))
        }
        scroll.addView(root, android.widget.FrameLayout.LayoutParams(-1, -2))

        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        top.addView(BlockMarkView(this), LinearLayout.LayoutParams(dp(48), dp(48)))
        val brand = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        brand.addView(label("BLOCKCRAFT JAVA", 15f, white, true))
        brand.addView(label("ULTRA HUB  /  ANDROID", 9f, muted, true).apply { letterSpacing = 0.10f })
        top.addView(brand, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(12) })
        top.addView(pill("BETA", bg, green))
        root.addView(top)

        addSpace(root, 26)
        root.addView(label("JAVA EDITION,\nIN YOUR POCKET.", 30f, white, true).apply {
            letterSpacing = -0.02f
            setLineSpacing(dp(1).toFloat(), 1f)
        })
        addSpace(root, 8)
        root.addView(label(
            "Your custom home for Minecraft: Java Edition on Android. Launch your game engine, then manage versions, mods and graphics there.",
            13f, muted, false
        ).apply { setLineSpacing(dp(3).toFloat(), 1f) })

        addSpace(root, 20)
        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(panelLight, 22)
            setPadding(dp(16), dp(16), dp(16), dp(16))
            clipToOutline = true
        }
        val heroHeader = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        heroHeader.addView(label("JAVA EDITION", 10f, green, true), LinearLayout.LayoutParams(0, -2, 1f))
        engineStatus = label("CHECKING ENGINE…", 9f, muted, true).apply { gravity = Gravity.END }
        heroHeader.addView(engineStatus)
        hero.addView(heroHeader)
        addSpace(hero, 12)
        hero.addView(PixelLandscapeView(this), LinearLayout.LayoutParams(-1, dp(112)))
        addSpace(hero, 12)
        hero.addView(label("READY FOR A NEW WORLD?", 18f, white, true))
        hero.addView(label(
            "This hub opens a compatible Java launcher. The game engine and Minecraft files are installed separately.",
            11f, muted, false
        ).apply { setPadding(0, dp(5), 0, 0); setLineSpacing(dp(2).toFloat(), 1f) })
        root.addView(hero, LinearLayout.LayoutParams(-1, -2))

        addSpace(root, 14)
        val play = actionButton("▶   START JAVA EDITION", green, 0xFF0B1A0F.toInt())
        play.setOnClickListener { launchJavaEngine() }
        root.addView(play, LinearLayout.LayoutParams(-1, dp(54)))

        addSpace(root, 22)
        root.addView(label("YOUR GAME TOOLS", 10f, green, true).apply { letterSpacing = 0.12f })
        addSpace(root, 10)

        val row1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row1.addView(featureCard("▦", "VERSIONS", "Choose game version", green) {
            showFeatureInfo("Minecraft versions", "Choose a Minecraft version inside your installed Java launcher. Let it download the required game files. Very old and very new versions may need different Java runtimes and may not run equally well on every phone.")
        }, LinearLayout.LayoutParams(0, dp(108), 1f))
        row1.addView(View(this), LinearLayout.LayoutParams(dp(10), 1))
        row1.addView(featureCard("✣", "MODS", "Fabric / Forge", white) {
            showFeatureInfo("Mods", "Install mods through your Java launcher or its supported mod manager. Match the mod to both your Minecraft version and mod loader (for example Fabric or Forge). Make a backup of your worlds first, and only install files from sources you trust.")
        }, LinearLayout.LayoutParams(0, dp(108), 1f))
        root.addView(row1)

        addSpace(root, 10)
        val row2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row2.addView(featureCard("✧", "SHADERS", "Graphics effects", green) {
            showFeatureInfo("Shaders", "Shader support depends on the Minecraft version, renderer, driver and phone GPU. Start with a lightweight shader and low graphics settings. If the game crashes or shows black textures, disable the shader and try another compatible renderer or pack. This hub does not install shaders by itself.")
        }, LinearLayout.LayoutParams(0, dp(108), 1f))
        row2.addView(View(this), LinearLayout.LayoutParams(dp(10), 1))
        row2.addView(featureCard("⚙", "PERFORMANCE", "6 GB RAM starter guide", white) {
            showPerformanceGuide()
        }, LinearLayout.LayoutParams(0, dp(108), 1f))
        root.addView(row2)

        addSpace(root, 22)
        root.addView(label("FIRST-TIME SETUP", 10f, green, true).apply { letterSpacing = 0.12f })
        addSpace(root, 10)
        val row3 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row3.addView(miniCard("＋", "GET A JAVA\nLAUNCHER", "Official release pages", green).apply {
            setOnClickListener { showLauncherChoices() }
        }, LinearLayout.LayoutParams(0, dp(100), 1f))
        row3.addView(View(this), LinearLayout.LayoutParams(dp(10), 1))
        row3.addView(miniCard("i", "QUICK\nSETUP GUIDE", "Sign-in & first launch", white).apply {
            setOnClickListener { showSetupGuide() }
        }, LinearLayout.LayoutParams(0, dp(100), 1f))
        root.addView(row3)

        addSpace(root, 18)
        val note = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(0xFF0C1912.toInt(), 16)
            setPadding(dp(14), dp(13), dp(14), dp(13))
        }
        note.addView(label("QUICK NOTE", 10f, green, true))
        note.addView(label(
            "6 GB physical RAM is still 6 GB even if your phone advertises 4 GB of memory expansion. Minecraft files are not bundled here. This fan-made app is not affiliated with Mojang or Microsoft.",
            11f, muted, false
        ).apply { setPadding(0, dp(6), 0, 0); setLineSpacing(dp(3).toFloat(), 1f) })
        root.addView(note)

        addSpace(root, 18)
        root.addView(label("MADE FOR ANDROID  •  VERSION 1.1.0", 9f, 0xFF718576.toInt(), true).apply {
            gravity = Gravity.CENTER
            letterSpacing = 0.05f
        })
        setContentView(scroll)
    }

    private fun launchJavaEngine() {
        val installed = engines.firstOrNull { isEngineInstalled(it.packageName) }
        if (installed == null) {
            showLauncherChoices()
            return
        }
        try {
            val launchIntent = packageManager.getLaunchIntentForPackage(installed.packageName)
            if (launchIntent != null) startActivity(launchIntent) else showLauncherChoices()
        } catch (_: ActivityNotFoundException) {
            showLauncherChoices()
        }
    }

    private fun isEngineInstalled(packageName: String): Boolean = try {
        packageManager.getLaunchIntentForPackage(packageName) != null
    } catch (_: Exception) {
        false
    }

    private fun refreshEngineStatus() {
        val installed = engines.firstOrNull { isEngineInstalled(it.packageName) }
        engineStatus?.text = if (installed == null) "ENGINE NOT INSTALLED" else "${installed.label.uppercase()} READY"
        engineStatus?.setTextColor(if (installed == null) 0xFFFFC66D.toInt() else green)
    }

    private fun showLauncherChoices() {
        val options = arrayOf("Download Amethyst (recommended to try)", "Get Fold Craft Launcher", "Cancel")
        AlertDialog.Builder(this)
            .setTitle("Choose a Java launcher")
            .setMessage("A separate compatible launcher supplies the Java runtime, rendering and game-version support. These are official project pages.")
            .setItems(options) { dialog, which ->
                when (which) {
                    0 -> openWeb("https://github.com/AngelAuraMC/Amethyst-Android/releases")
                    1 -> openWeb("https://github.com/FCL-Team/FoldCraftLauncher/releases")
                    else -> dialog.dismiss()
                }
            }
            .setNegativeButton("Close", null)
            .show()
    }

    private fun showFeatureInfo(title: String, message: String) {
        AlertDialog.Builder(this)
            .setTitle(title)
            .setMessage(message)
            .setPositiveButton("OPEN JAVA LAUNCHER") { _, _ -> launchJavaEngine() }
            .setNeutralButton("GET A LAUNCHER") { _, _ -> showLauncherChoices() }
            .setNegativeButton("CLOSE", null)
            .show()
    }

    private fun showPerformanceGuide() {
        AlertDialog.Builder(this)
            .setTitle("Performance starter guide")
            .setMessage(
                "For a phone with 6 GB physical RAM, try allocating about 1.5–2 GB to Minecraft first, if your Java launcher offers a RAM setting. More RAM is not always faster.\n\n" +
                "• Close heavy apps before playing.\n" +
                "• Start with a lower render distance (4–8 chunks).\n" +
                "• Test without shaders first.\n" +
                "• If the game stutters or Android closes it, lower memory or graphics settings.\n\n" +
                "The extra 4 GB memory expansion is not the same as physical RAM, and actual performance depends on your phone's processor and GPU."
            )
            .setPositiveButton("OPEN JAVA LAUNCHER") { _, _ -> launchJavaEngine() }
            .setNegativeButton("CLOSE", null)
            .show()
    }

    private fun showSetupGuide() {
        AlertDialog.Builder(this)
            .setTitle("Quick setup")
            .setMessage(
                "1. Install Amethyst or Fold Craft Launcher from the official release page.\n\n" +
                "2. Open it and follow the setup steps.\n\n" +
                "3. Sign in only in the trusted launcher with the Microsoft account that owns Minecraft: Java Edition.\n\n" +
                "4. Pick a version and let the launcher download its game files.\n\n" +
                "5. Test vanilla gameplay first. Add mods or shaders only after the base game works.\n\n" +
                "Performance and compatibility depend on your Android version, processor, GPU and the selected game version."
            )
            .setPositiveButton("CHOOSE LAUNCHER") { _, _ -> showLauncherChoices() }
            .setNegativeButton("CLOSE", null)
            .show()
    }

    private fun openWeb(url: String) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        } catch (_: ActivityNotFoundException) {
            Toast.makeText(this, "No browser app was found.", Toast.LENGTH_LONG).show()
        }
    }

    private fun featureCard(symbol: String, title: String, subtitle: String, symbolColor: Int, click: () -> Unit): LinearLayout {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(panel, 16)
            setPadding(dp(13), dp(12), dp(10), dp(10))
            isClickable = true
            isFocusable = true
            foreground = selectableForeground()
            setOnClickListener { click() }
        }
        card.addView(label(symbol, 20f, symbolColor, true))
        addSpace(card, 4)
        card.addView(label(title, 12f, white, true))
        card.addView(label(subtitle, 10f, muted, false).apply { setPadding(0, dp(3), 0, 0) })
        return card
    }

    private fun miniCard(symbol: String, title: String, subtitle: String, symbolColor: Int): LinearLayout {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(panel, 16)
            setPadding(dp(13), dp(12), dp(10), dp(10))
            isClickable = true
            isFocusable = true
            foreground = selectableForeground()
        }
        card.addView(label(symbol, 20f, symbolColor, true))
        addSpace(card, 4)
        card.addView(label(title, 12f, white, true).apply { setLineSpacing(0f, 0.95f) })
        card.addView(label(subtitle, 10f, muted, false).apply { setPadding(0, dp(3), 0, 0) })
        return card
    }

    private fun actionButton(text: String, fill: Int, textColor: Int): Button = Button(this).apply {
        this.text = text
        setTextColor(textColor)
        textSize = 13f
        typeface = Typeface.create("sans-serif", Typeface.BOLD)
        isAllCaps = false
        background = rounded(fill, 16)
        minHeight = dp(54)
        minimumHeight = dp(54)
        setPadding(dp(16), 0, dp(16), 0)
        stateListAnimator = null
        foreground = selectableForeground()
    }

    private fun label(text: String, size: Float, color: Int, bold: Boolean): TextView = TextView(this).apply {
        this.text = text
        textSize = size
        setTextColor(color)
        typeface = Typeface.create("sans-serif", if (bold) Typeface.BOLD else Typeface.NORMAL)
        includeFontPadding = true
    }

    private fun pill(text: String, fill: Int, textColor: Int): TextView = label(text, 9f, textColor, true).apply {
        gravity = Gravity.CENTER
        setPadding(dp(10), dp(6), dp(10), dp(6))
        background = rounded(fill, 30)
    }

    private fun rounded(color: Int, radiusDp: Int): GradientDrawable = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radiusDp).toFloat()
    }

    private fun selectableForeground(): android.graphics.drawable.Drawable? {
        val value = android.util.TypedValue()
        theme.resolveAttribute(android.R.attr.selectableItemBackground, value, true)
        return if (value.resourceId != 0) getDrawable(value.resourceId) else null
    }

    private fun addSpace(parent: LinearLayout, heightDp: Int) {
        parent.addView(View(this), LinearLayout.LayoutParams(1, dp(heightDp)))
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density + 0.5f).toInt()

    private class BlockMarkView(context: android.content.Context) : View(context) {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val unit = width / 6f
            paint.color = 0xFF205B35.toInt()
            canvas.drawRoundRect(RectF(unit * .35f, unit * .35f, unit * 5.65f, unit * 5.65f), unit * .55f, unit * .55f, paint)
            paint.color = 0xFF76D957.toInt()
            canvas.drawRect(unit * .75f, unit * .75f, unit * 5.25f, unit * 2.55f, paint)
            paint.color = 0xFF54B83B.toInt()
            canvas.drawRect(unit * .75f, unit * 2.55f, unit * 2.4f, unit * 4.95f, paint)
            canvas.drawRect(unit * 3.85f, unit * 2.55f, unit * 5.25f, unit * 4.95f, paint)
            paint.color = 0xFF8BEA62.toInt()
            canvas.drawRect(unit * 2.4f, unit * 2.55f, unit * 3.85f, unit * 3.45f, paint)
            paint.color = 0xFF17472B.toInt()
            canvas.drawRect(unit * 2.4f, unit * 3.45f, unit * 3.85f, unit * 4.95f, paint)
        }
    }

    private class PixelLandscapeView(context: android.content.Context) : View(context) {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val w = width.toFloat()
            val h = height.toFloat()
            paint.color = 0xFF1D3D2A.toInt()
            canvas.drawRoundRect(0f, 0f, w, h, 14f, 14f, paint)
            paint.color = 0xFFFFD46A.toInt()
            canvas.drawRect(w * .72f, h * .12f, w * .86f, h * .43f, paint)
            paint.color = 0xFF2C6840.toInt()
            canvas.drawRect(0f, h * .52f, w * .30f, h * .82f, paint)
            canvas.drawRect(w * .18f, h * .35f, w * .45f, h * .82f, paint)
            canvas.drawRect(w * .36f, h * .56f, w * .62f, h * .82f, paint)
            canvas.drawRect(w * .60f, h * .46f, w, h * .82f, paint)
            paint.color = 0xFF4B9945.toInt()
            canvas.drawRect(0f, h * .78f, w * .43f, h, paint)
            canvas.drawRect(w * .43f, h * .82f, w, h, paint)
            paint.color = 0xFF8BEA62.toInt()
            canvas.drawRect(w * .08f, h * .78f, w * .20f, h * .86f, paint)
            canvas.drawRect(w * .50f, h * .82f, w * .63f, h * .90f, paint)
            paint.color = 0xFF246137.toInt()
            canvas.drawRect(w * .27f, h * .87f, w * .39f, h, paint)
            canvas.drawRect(w * .79f, h * .86f, w * .93f, h, paint)
        }
    }
}
